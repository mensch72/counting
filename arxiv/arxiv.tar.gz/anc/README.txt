Ancillary files for "Counting distributive and modular lattices with a frontier transfer matrix".
b006982.txt  distributive lattices d(n), n <= 160          b072361.txt  vertically indecomposable ones
b006981.txt  modular lattices m(n)                          b342132.txt  vertically indecomposable ones
b229202.txt  semimodular lattices                           b072407.txt, b186808.txt  derived sequences
bounded_*.txt  growth rates of the bounded-layer automata and the exact certificates
src/, scripts/  the programs (C++, needs nauty) and the checking scripts; see
https://github.com/mensch72/counting for instructions, logs and the full history.
